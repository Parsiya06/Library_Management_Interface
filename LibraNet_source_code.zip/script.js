const $ = id => document.getElementById(id);
const FINE_PER_DAY = 2;

const defaultBooks = [
  { id: 1, title: "Python Programming", author: "Mark Lutz", isbn: "9789355421234", category: "Computer Science", quantity: 5, available: 5 },
  { id: 2, title: "Engineering Mathematics", author: "B.S. Grewal", isbn: "9788174091953", category: "Mathematics", quantity: 1, available: 1 },
  { id: 3, title: "Data Science Basics", author: "Joel Grus", isbn: "9789352136841", category: "Data Science", quantity: 3, available: 3 },
  { id: 4, title: "Web Development with HTML", author: "Jon Duckett", isbn: "9781118008188", category: "Computer Science", quantity: 4, available: 4 },
  { id: 5, title: "Statistics for Beginners", author: "S.C. Gupta", isbn: "9788180547294", category: "Mathematics", quantity: 4, available: 4 }
];

let books = JSON.parse(localStorage.getItem("lib_books")) || defaultBooks;
let records = JSON.parse(localStorage.getItem("lib_records")) || [];
let editingId = null;

function save() {
  localStorage.setItem("lib_books", JSON.stringify(books));
  localStorage.setItem("lib_records", JSON.stringify(records));
}
function today() { return new Date().toISOString().split("T")[0]; }
function addDays(n) { return new Date(Date.now() + n * 864e5).toISOString().split("T")[0]; }
function isOverdue(r) { return r.status === "Issued" && r.dueDate < today(); }

function init() {
  $("issueDate").value = today();
  $("dueDate").value = addDays(7);
  $("returnDate").value = today();
  refreshAll();
}

function refreshAll() {
  updateStats(); loadCategories(); displayBooks(); fillSelects(); renderRecords();
}

function updateStats() {
  let total = books.reduce((s, b) => s + b.quantity, 0);
  let avail = books.reduce((s, b) => s + b.available, 0);
  $("totalTitles").textContent = books.length;
  $("totalCopies").textContent = total;
  $("availCopies").textContent = avail;
  $("issuedCopies").textContent = total - avail;
  $("overdueCount").textContent = records.filter(isOverdue).length;
  $("returnedCount").textContent = records.filter(r => r.status === "Returned").length;
}

function loadCategories() {
  let current = $("category").value;
  let cats = [...new Set(books.map(b => b.category))];
  $("category").innerHTML = '<option value="all">All Categories</option>' +
    cats.map(c => `<option>${c}</option>`).join("");
  $("category").value = cats.includes(current) ? current : "all";
}

function displayBooks() {
  let q = $("search").value.toLowerCase();
  let filtered = books.filter(b =>
    (b.title.toLowerCase().includes(q) || b.author.toLowerCase().includes(q) || b.isbn.includes(q)) &&
    ($("category").value === "all" || b.category === $("category").value) &&
    ($("availability").value === "all" ||
     ($("availability").value === "available" ? b.available > 0 : b.available < b.quantity || b.available === 0)));
  $("bookList").innerHTML = filtered.map(b => `
    <div class="book-card">
      <h3>${b.title}</h3>
      <p><b>Author:</b> ${b.author}</p>
      <p><b>ISBN:</b> ${b.isbn}</p>
      <p><b>Category:</b> ${b.category}</p>
      <div class="qty">
        <div><b>${b.quantity}</b>Quantity</div>
        <div><b>${b.available}</b>Available</div>
        <div><b>${b.quantity - b.available}</b>Issued</div>
      </div>
      <span class="status ${b.available > 0 ? "available" : "issued"}">
        ${b.available > 0 ? "Available" : "Out of stock"}</span>
      <div class="actions">
        <button class="edit-btn" onclick="editBook(${b.id})">Edit</button>
        <button class="del-btn" onclick="deleteBook(${b.id})">Delete</button>
      </div>
    </div>`).join("") || "<p>No books found.</p>";
}

function saveBook() {
  let b = { title: $("bTitle").value.trim(), author: $("bAuthor").value.trim(),
    isbn: $("bIsbn").value.trim(), category: $("bCategory").value.trim(), quantity: Number($("bQty").value) };
  if (!b.title || !b.author || !b.isbn || !b.category || b.quantity < 1) {
    showNotice("manageNotice", "Please fill all fields with a valid quantity.", true); return;
  }
  if (editingId) {
    let old = books.find(x => x.id === editingId);
    let issued = old.quantity - old.available;
    if (b.quantity < issued) { showNotice("manageNotice", "Quantity cannot be less than issued copies (" + issued + ").", true); return; }
    Object.assign(old, b, { available: b.quantity - issued });
    showNotice("manageNotice", "Book updated successfully!");
  } else {
    books.push({ id: Date.now(), ...b, available: b.quantity });
    showNotice("manageNotice", "Book added successfully!");
  }
  save(); resetForm(); refreshAll();
}

function editBook(id) {
  let b = books.find(x => x.id === id);
  editingId = id;
  $("formTitle").textContent = "Edit Book";
  $("bTitle").value = b.title; $("bAuthor").value = b.author; $("bIsbn").value = b.isbn;
  $("bCategory").value = b.category; $("bQty").value = b.quantity;
  showNotice("manageNotice", "");
  navigate("manage");
}

function deleteBook(id) {
  let b = books.find(x => x.id === id);
  if (b.available < b.quantity) { alert("This book has issued copies and cannot be deleted."); return; }
  if (!confirm("Delete '" + b.title + "'?")) return;
  books = books.filter(x => x.id !== id);
  save(); refreshAll();
}

function resetForm() {
  editingId = null; $("formTitle").textContent = "Add Book";
  ["bTitle", "bAuthor", "bIsbn", "bCategory", "bQty"].forEach(i => $(i).value = "");
}

function keepValue(id, value) {
  if ([...$(id).options].some(o => o.value === value)) $(id).value = value;
}

function fillSelects() {
  let oldBook = $("bookSelect").value, oldReturn = $("returnSelect").value;
  $("bookSelect").innerHTML = books.map(b =>
    `<option value="${b.id}">${b.title} (${b.available} available)</option>`).join("");
  let active = records.filter(r => r.status === "Issued");
  $("returnSelect").innerHTML = active.length
    ? active.map(r => `<option value="${r.id}">${r.borrower} - ${r.title}</option>`).join("")
    : "<option value=''>No issued books</option>";
  keepValue("bookSelect", oldBook); keepValue("returnSelect", oldReturn);
}

function issueBook() {
  let book = books.find(b => b.id === Number($("bookSelect").value));
  if (!$("borrower").value.trim() || !$("borrowerId").value.trim() || !book) {
    showNotice("issueNotice", "Enter borrower name, ID and select a book.", true); return;
  }
  if (book.available <= 0) {
    showNotice("issueNotice", "No copies available. This book cannot be issued.", true); return;
  }
  book.available--;
  records.push({ id: Date.now(), bookId: book.id, title: book.title, borrower: $("borrower").value.trim(),
    borrowerId: $("borrowerId").value.trim(), issueDate: $("issueDate").value, dueDate: $("dueDate").value,
    returnDate: null, fine: 0, status: "Issued" });
  save(); refreshAll();
  showNotice("issueNotice", "Book issued successfully!");
}

function returnBook() {
  let r = records.find(x => x.id === Number($("returnSelect").value));
  if (!r) { showNotice("returnNotice", "Select an issued book.", true); return; }
  let lateDays = Math.ceil((new Date($("returnDate").value) - new Date(r.dueDate)) / 864e5);
  r.fine = lateDays > 0 ? lateDays * FINE_PER_DAY : 0;
  r.returnDate = $("returnDate").value; r.status = "Returned";
  books.find(b => b.id === r.bookId).available++;
  save(); refreshAll();
  showNotice("returnNotice", r.title + " returned by " + r.borrower + ". Fine: Rs. " + r.fine);
}

function renderRecords() {
  $("recordList").innerHTML = records.length ? records.slice().reverse().map(r => {
    let st = isOverdue(r) ? "Overdue" : r.status;
    return `<div class="record-row"><b>${r.title}</b><br>
      Borrower: ${r.borrower} (${r.borrowerId})<br>
      Issued: ${r.issueDate} | Due: ${r.dueDate}<br>
      <span class="status ${st.toLowerCase()}">${st}</span>
      ${r.status === "Returned" ? " Returned: " + r.returnDate + " | Fine: Rs. " + r.fine : ""}</div>`;
  }).join("") : "<p>No records yet.</p>";
}

function showNotice(id, msg, isError) {
  $(id).textContent = msg;
  $(id).className = "notice" + (isError ? " error" : "");
}

function navigate(pageId) {
  document.querySelectorAll(".page").forEach(p => p.classList.remove("active"));
  $(pageId).classList.add("active");
  window.scrollTo(0, 0);
}
window.onload = init;
